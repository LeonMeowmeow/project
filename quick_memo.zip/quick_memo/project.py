import datetime
import os
import time

LINE :str = "ー"*50
FILENAME : str= os.path.join(os.path.dirname(__file__),"todolist.txt")

#if can't find file -> create one
try:
    with open(FILENAME, "r") as file:
        pass
except FileNotFoundError:
    with open (FILENAME,"w"):
        pass

#clear screen
def clear():
    os.system("cls" if os.name=="nt" else "clear")

def pr_line():
    print(LINE)

# Function to read file and transfer content to list of dictionaries
def read_file():
    global todo_list
    try:
        with open(FILENAME, 'r+') as file:
            todo_list = []
            content = file.readlines()
        for i in range(len(content)-1,-1,-1):
            if (content[i] == "\n"):
                content.pop(i)
        for i in range(len(content)):
            content[i] = content[i].strip("\n")
        for line in content:
            date_str, task = line.split('`')
            year, month, day = map(int, date_str.split('/'))
            todo_list.append({'year': year, 'month': month, 'day': day, 'task': task})
        
    except FileNotFoundError:
        todo_list = []


# Function to show the list
def show_list():
    combined_dict = {}
    for item in todo_list:
        date_key = (item['year'], item['month'], item['day'])
        if date_key in combined_dict:
            combined_dict[date_key].append(item['task'])
        else:
            combined_dict[date_key] = [item['task']]
    index = 1
    for _, (date_key, tasks) in enumerate(sorted(combined_dict.items()), start=1):
        date_str = f"{date_key[0]}/{date_key[1]:02d}/{date_key[2]:02d}"
        for i in tasks :
            print(f"{index:2d}. {date_str} : {i}")
            index += 1
            

# Function to detect wrong date
def validate_date(year, month, day):
    try:
        datetime.datetime(year, month, day)
        return True
    except ValueError:
        return False



# Function to add a new item to the list
def add_item():
    try:
        year = int(input("Enter the year (YYYY): "))
        month = int(input("Enter the month (MM): "))
        day = int(input("Enter the day (DD): "))
        if not validate_date(year, month, day):
            print("Invalid date. Please try again.")
            return
        task = input("Enter the task: ")
        todo_list.append({'year': year, 'month': month, 'day': day, 'task': task})
    except ValueError:
        print("Invalid input. Please enter again.")

# Function to write list to file

def write_file():
    combined_dict = {}
    for item in todo_list:
        date_key = (item['year'], item['month'], item['day'])
        if date_key in combined_dict:
            combined_dict[date_key].append(item['task'])
        else:
            combined_dict[date_key] = [item['task']]

    with open(FILENAME, 'w') as file:
        for date_key, tasks in sorted(combined_dict.items()):
            date_str = f"{date_key[0]}/{date_key[1]}/{date_key[2]}"
            for task in tasks:
                file.write(f"{date_str}`{task}\n")

def write_item():
    read_file()
    while True:
        print("\nTo-Do List:")
        show_list()
        print("\nOptions: [1] Add Item [2] Show To-do List [3] Save & Exit")
        choice = int(input("Choose an option: "))

        if choice == 1:
            add_item()
        elif choice == 2:
            show_list()
        elif choice == 3:
            write_file()
            print("To-do list saved!")
            break
        else:
            print("Invalid option. Please try again.")

def remove_memo():                                
    with open(FILENAME, "r") as f:
         #read the memo list order by number
        content = f.readlines()
        line_num = 0
        pr_line()
        for i in range(len(content)-1,-1,-1):
            if (content[i] == "\n"):
                content.pop(i)
        for i in range(len(content)):
            content[i] = content[i].strip("\n")
            line_num = i + 1
            date , thing = content[i].split("`")[0] , content[i].split("`")[1]
            year , month , day = date.split("/")[0] , date.split("/")[1] , date.split("/")[2]
            print(f"{line_num}.{year:>04}/{month:>02}/{day:>02}: {thing}", sep="")
        #remove memo 
        while True:
            try:
                pr_line()
                remove_list = int(input("Remove the thing you want(Type the corresponding number): ")) 
                if (remove_list > len(content)) or (remove_list <= 0):
                    assert False, f"Please type (1~{len(content)})"    
                break
            except ValueError:
                print("Please input a integer.")
            except AssertionError as msg:
                print(msg)

        remove_list = content.pop(remove_list - 1)
        pr_line()
        date , thing = remove_list.split("`")[0] , remove_list.split("`")[1]
        year , month , day = date.split("/")[0] , date.split("/")[1] , date.split("/")[2]
        print(f"The thing you removed is: {year:>04}/{month:>02}/{day:>02}: {thing}", sep="")
        pr_line()


        #read the updated memo list
        time.sleep(2)
        print("The list is: ")
        for i in range(len(content)):
            content[i] = content[i].strip("\n")
            line_num = i + 1
            date , thing = content[i].split("`")[0] , content[i].split("`")[1]
            year , month , day = date.split("/")[0] , date.split("/")[1] , date.split("/")[2]
            print(f"{line_num}. {year:>04}/{month:>02}/{day:>02}: {thing}", sep="")
        pr_line()
    #update the memo list        
    with open(FILENAME, "w") as f:
        for i in range(len(content)):
            f.write(f"{content[i]}\n")

def read_todolist_file():
    global todo_list
    todo_list = []
    with open(FILENAME,"r+") as file:
        content = file.readlines()
        #remove empty lines
        for i in range(len(content)-1,-1,-1):
            if (content[i] == "\n"):
                content.pop(i)
        #remove "\n" and append to the list
        for i in range(len(content)):
            content[i] = content[i].strip("\n")
            todo_list.append({"date":content[i].split("`")[0],"thing":content[i].split("`")[1]})
        #sort the list by the "date"
        todo_list.sort(key=lambda x : x["date"])

def pr_item():
    read_todolist_file()
    #print the list
    print("The to-do list is:")
    j = 1
    for i in todo_list:
        year , month , day = int(i["date"].split("/")[0]) , int(i["date"].split("/")[1]) , int(i["date"].split("/")[2])
        print(f" {j:2d}.{year:04d}/{month:02d}/{day:02d}: {i["thing"]}")
        j += 1
    pr_line()

def pr_calendar():
    BOLD_UNDERLINE_START = "\033[1m\033[4m"
    BOLD_UNDERLINE_END = "\033[0m"
    # HAVE_ITEMS_STORED = True
    global calendar_year 
    global calendar_month 
    if (calendar_month >= 13):
        calendar_month = 1
        calendar_year += 1
    MONTH ={1:'January', 2:'February', 3:'March', 
            4:'April', 5:'May', 6:'June', 7:'July', 
            8:'August', 9:'September', 10:'October', 
            11:'November', 12:'December'} 

    # code below for calculation of odd days 
    week_day = (calendar_year-1) % 400
    week_day = (week_day//100)*5 + ((week_day % 100) - (week_day % 100)//4) + ((week_day % 100)//4)*2
    week_day = week_day % 7

    non_leap_year =(31, 28, 31, 30, 31, 30, 
        31, 31, 30, 31, 30, 31) 
    leap_year =(31, 29, 31, 30, 31, 30, 
        31, 31, 30, 31, 30, 31) 
    total_days = 0

    if calendar_year % 4 == 0: 
        for i in range(calendar_month-1): 
            total_days += leap_year[i] 
    else: 
        for i in range(calendar_month-1): 
            total_days += non_leap_year[i] 

    week_day += total_days % 7
    week_day = week_day % 7

    # variable used for white space filling 
    # where date not present 
    SPACE = "   " 
    month_year = str(MONTH[calendar_month]) + " " + str(calendar_year)
    # code below is to print the calendar 
    print(f"The calendar of {calendar_year:04d}/{calendar_month:02d}(YYYY/MM) is :  (if there is an star(*) near the day, there are something need to do in that day)")
    print("{:^27}".format(month_year)) 
    print('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat') 

    if (calendar_month == 4) or (calendar_month == 6) or (calendar_month == 9) or (calendar_month == 11): 
        CHANGED = False
        for i in range(31 + week_day):
            date = f"{calendar_year}/{calendar_month}/{i-week_day}"
            if not(CHANGED):
                for lst in range(len(todo_list)):
                    todo_list[lst] = {"date":f"{todo_list[lst]["year"]}/{todo_list[lst]["month"]}/{todo_list[lst]["day"]}","thing":f"{todo_list[lst]["task"]}"}
                CHANGED = True
            for dates in todo_list:
                if (date == dates["date"]):
                    HAVE_ITEMS_STORED = True
                    break
                else :
                    HAVE_ITEMS_STORED = False
            if i<= week_day: 
                print(SPACE , end=" ") 
            else:
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_START , end = "") 
                if HAVE_ITEMS_STORED:
                    i_s = "*" + str(i - week_day)
                    print(f"{i_s:>3s}", end=" ") 
                else:
                    print(f"{(i - week_day):>3d}", end=" ") 
                if (i + 1)% 7 == 0: 
                    print()
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_END , end = "") 
    elif (calendar_month == 2): 
        if calendar_year % 4 == 0: 
            feb_days = 30
        else: 
            feb_days = 29
        CHANGED = False
        for i in range(feb_days + week_day): 
            date = f"{calendar_year}/{calendar_month}/{i - week_day}"
            if not(CHANGED):
                for lst in range(len(todo_list)):
                    todo_list[lst] = {"date":f"{todo_list[lst]["year"]}/{todo_list[lst]["month"]}/{todo_list[lst]["day"]}","thing":f"{todo_list[lst]["task"]}"}
                CHANGED = True
            for dates in todo_list:
                if date in dates["date"]:
                    HAVE_ITEMS_STORED = True
                else :
                    HAVE_ITEMS_STORED = False
                        
            
            if (i<= week_day): 
                print(SPACE, end =' ') 
            else: 
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_START , end = "") 
                if HAVE_ITEMS_STORED:
                    i_s = "*" + str(i - week_day)
                    print(f"{i_s:>3s}", end=" ") 
                else:
                    print(f"{(i - week_day):>3d}", end=" ") 
                if (i + 1)% 7 == 0: 
                    print() 
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_END , end = "") 
    else: 
        next_line = False
        if (calendar_year == 2024) and (calendar_month == 12):
            next_line = True
        CHANGED = False
        for i in range(32 + week_day): 
            date = f"{calendar_year}/{calendar_month}/{i - week_day}"
            if not(CHANGED):
                for lst in range(len(todo_list)):
                    todo_list[lst] = {"date":f"{todo_list[lst]["year"]}/{todo_list[lst]["month"]}/{todo_list[lst]["day"]}","thing":f"{todo_list[lst]["task"]}"}
                CHANGED = True
            for dates in todo_list:
                if date in dates["date"]:
                    HAVE_ITEMS_STORED = True
                else :
                    HAVE_ITEMS_STORED = False
            
            if i <= week_day: 
                print(SPACE, end =' ') 
            
            else: 
                if (next_line):
                    print()
                    next_line = False
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_START , end = "") 
                if HAVE_ITEMS_STORED:
                    i_s = "*" + str(i - week_day)
                    print(f"{i_s:>3s}", end=" ") 
                else:
                    print(f"{(i - week_day):>3d}", end=" ") 
                if (i + 1)% 7 == 0: 
                    print() 
                if ((i - week_day) == time.localtime().tm_mday) and (calendar_month == time.localtime().tm_mon):
                    print(BOLD_UNDERLINE_END , end = "") 


def read_thing_by_calendar_date():
    global todo_list
    while True:
        try:
            back_flag = False
            print("Please type the date of the item you want to know (if you want to go to previous page, please type 0):")
            year = int(input("Year: "))
            if (year<0):
                assert False , "The year should be positive"
            elif (year == 0):
                assert False , "Back"
            month = int(input("Month(1~12): "))
            if (month > 12) or (month < 0):
                assert False , "The month should be 1~12"
            elif (month == 0):
                assert False , "Back"
            elif(month == 2):
                if (((year%4==0) and (year%100 != 0)) or (year %400 == 0)):
                    max_day = 29
                else : 
                    max_day = 28          
            elif (month == 2) or (month == 4) or (month == 6) or (month == 9) or (month == 11) :
                max_day = 30
            else :
                max_day = 31
            day = int(input(f"Day(1~{max_day}): "))
            if (day > max_day) or (day < 0):
                assert False , f"Please type 1~{max_day}"
            elif (day == 0):
                assert False , "Back"
            back_flag = False
            break
        except ValueError:
            print("Please type an integer.")
        except AssertionError as wrong_msg:
            back_flag = True
            if (str(wrong_msg) != "Back"):
                print(wrong_msg)
                time.sleep(1)
                back_flag = False
            if (str(wrong_msg) == "Back"):
                break
    
    if (back_flag is False):
        date_input = f"{year}/{month}/{day}"
        todo_list = []
        with open(FILENAME,"r+") as file:
            content = file.readlines()
            #remove empty lines
            for i in range(len(content)-1,-1,-1):
                if (content[i] == "\n"):
                    content.pop(i)
            #remove "\n" and append to the list
            for i in range(len(content)):
                content[i] = content[i].strip("\n")
                todo_list.append({"date":content[i].split("`")[0],"thing":content[i].split("`")[1]})
            #sort the list by the "date" in the dictionary in the todolist
            todo_list.sort(key=lambda x : x["date"])
            item_in_list = False
            while (item_in_list is False):
                for i in todo_list:
                    if (i["date"] == date_input):
                        item_in_list = True
                        pr_line()
                        print(f"Things you need to do in {date_input}:")
                        break
                break
            if (item_in_list is True):
                count = 1
                for i in todo_list:
                    if (i["date"] == date_input):
                        print(f" {count}. {i["thing"]}")
                        count += 1
                pr_line()
            else:
                pr_line()
                print(f"There is nothing in {date_input}")
                pr_line()



calendar_year = time.localtime().tm_year
calendar_month = time.localtime().tm_mon
def read_item_by_calendar():
    read_file()
    while True :
        try:
            global calendar_year
            global calendar_month
            print("Please choose what date you want: \n 1. Show the calendar this month \n 2. Show the next month \n 3. Show the things in the todo list in the date chosen")
            choice = int(input())
            if choice == 1:
                calendar_year = time.localtime().tm_year
                calendar_month = time.localtime().tm_mon
                pr_calendar()
                print()
                pr_line()
            elif choice == 2:
                calendar_month += 1
                pr_calendar()
                print()
                pr_line()
            
            elif choice == 3:
                read_thing_by_calendar_date()
            else :
                assert False, "Please type (1~3)"
            break
        except ValueError:
            clear()
            print("Please type an integer.")
        except AssertionError as msg:
            clear()
            print(msg)
            time.sleep(1)
            pr_line()

#The start of the program
def prog_start():
    print("\rPlease choose a function by typing number(1~4):(if you want to leave, please type 0) \n 1. Read whole to-do list \n 2. Read the items by calendar \n 3. Add items to the to-do list \n 4. Remove an item from the to-do list ")
    check_choice()

def check_choice():
    while True :
        try:
            choice = int( input ())
            int(choice)
            clear()
            if (int(choice) > 4 or int(choice) < 0):
                assert False , "The number should be 1~4. Please type again." 
            elif choice == 1 :
                pr_item()
                input("Please press \"Enter\" to continue\r")
                clear()
                prog_start()
                break
            elif choice == 2 :
                read_item_by_calendar()
                input("Please press \"Enter\" to continue\r")
                clear()
                prog_start()
                break
            elif choice == 3 :
                read_file()
                write_item()
                input("Please press \"Enter\" to continue\r")
                clear()
                prog_start()
                break
            elif choice == 4 :
                remove_memo()
                input("Please press \"Enter\" to continue\r")
                clear()
                prog_start()
                break
            elif choice == 0 :
                break
        except ValueError:
            clear()
            print (f"{LINE}\nPlease type an integer.")
            time.sleep(1)
            pr_line()
            print("\rPlease choose a function by typing number(1~4):(if you want to leave, please type 0) \n 1. Read whole to-do list \n 2. Read the items by calendar \n 3. Add items to the to-do list \n 4. Remove an item from the to-do list ")
        except AssertionError as wrong_msg:
            print (f"{LINE}\n{wrong_msg}")
            time.sleep(1)
            pr_line()
            print("\rPlease choose a function by typing number(1~4):(if you want to leave, please type 0) \n 1. Read whole to-do list \n 2. Read the items by calendar \n 3. Add items to the to-do list \n 4. Remove an item from the to-do list ")

prog_start()
# read_file()