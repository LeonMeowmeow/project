from time import sleep
from product_checking import Product_C, update
from readio import FILENAME, reader, line, clear_screen, inventory
from report_product import report_menu


def load_Inventory():
    for lines in reader(FILENAME):
        lines = lines.strip("\n")
        line_split = lines.split(",")
        key = line_split[0]
        key_val_dict = {}
        for i in range(1, len(line_split)):
            key_val_dict[line_split[i].split(":")[0]] = line_split[i].split(":")[1]
        inventory.add(key, **key_val_dict)


# save the current state of the inventory to the inventory text file.
def save_Inventory():
    with open(FILENAME, "w") as file:
        for lines in inventory:
            for node in lines:
                file.write(f"{str(node)}\n")


# add item to the inventory
def add_Items():
    while True:
        try:
            line()
            item_name = input("Please enter the item name: (type '-1' to go back to menu)\n")
            if item_name.strip() == "-1":
                break
            if item_name.strip() == "":
                raise ValueError
            line()
            category = input("Please enter the category of the item: (type '-1' to go back to menu)\n")
            if category.strip() == "-1":
                break
            if category.strip() == "":
                raise ValueError
            line()
            stock = int(input("Please enter the stock amount(enter number): (type '-1' to go back to menu)\n"))
            if stock == -1:
                break
            if stock < 0:
                raise ValueError
            line()
            price = int(input("Please enter the price(HKD): (type '-1' to go back to menu)\n"))
            if price == -1:
                break
            if price <= 0:
                raise ValueError
            line()
            sold = int(input("Please enter the selling number of item: (type '-1' to go back to menu)\n"))
            if sold == -1:
                break
            if sold < 0:
                raise ValueError
            line()
            break
        except ValueError:
            print("Wrong input! Please try again")
            sleep(0.5)

    try:
        inventory.add(item_name, price=price,stock=stock, sold=sold, category=category)
        print(f"Added {item_name} of {category} with stock {stock}, price(HKD) {price} and selling number {sold}")
        save_Inventory()
    except KeyError as e:
        print(e)
    except UnboundLocalError:
        pass


# remove items from the inventory.
def remove_Items():
    item = input("Enter the name of the item to remove: (type '-1' to go back to menu)\n")
    if item != "-1":
        try:
            inventory.remove(item)
            print(f"Removed {item} from the inventory.")
            update_removing()
        except KeyError as e:
            print(e)


# update the inventory text file while removing item
def update_removing():
    with open(FILENAME, "w") as file:
        for i in inventory:
            for node in i:
                file.write(f"{str(node)}\n")


# display the current inventory text file.
def display_inventory():
    Product_C()


# start the program and load existing inventory from file
def start_prog():
    load_Inventory()
    update()

    while True:
        print("-"*61 + " GOODs Inventory " + "-"*61)
        print(f"|{"Welcome to GOODS Inventory, we hope you can make GOOD inventory for your stocks. Let's make your choice!":136} |")
        print(f"|{'0. Quit':136} |")
        print(f"|{"1. Add items":136} |")
        print(f"|{"2. Remove items":136} |")
        print(f"|{"3. Display Inventory":136} |")
        print(f"|{"4. Generate a report":136} |")
        line()
        choice = input("Enter your choice: ")
        match choice:
            case "1":
                add_Items()
                line()
                input("Press enter to continue")
                line()
                clear_screen()
            case "2":
                line()
                remove_Items()
                input("Press enter to continue")
                clear_screen()
            case "3":
                line()
                print("Your stored inventory is shown as follows: ")
                display_inventory()
                line()
                input("Press enter to continue")
                clear_screen()
            case "4":
                line()
                report_menu()
                line()
                input("Press enter to continue")
                clear_screen()
            case "0":
                clear_screen()
                break
            case _:
                print("Invalid choice. Please try again.")


if __name__ == "__main__":
    start_prog()
