from hashtable import HashTable
from readio import FILENAME, reader, line, clear_screen, inventory


def get_inventory():
    line(1)
    print(f"|{'Inventory Report: Items Bought and Sold':^138}|")
    line(1)
    for linked_list in inventory:
        for node in linked_list:
            attributes = {"price": node.kwval.get('price', 0), "stock": node.kwval.get('stock', 0), "sold": node.kwval.get('sold', 0)}
            print(f"| {node.key:^67} |", end="")
            for k, v in attributes.items():
                print(f"  {f"{k}: {v}":18}  |", end="")
            print()
    line(1)


# Display the top 5 best-selling and worst-selling items with profit
def get_top5_report():
    all_items = []
    for linked_list in inventory:
        for node in linked_list:
            all_items.append(node)

    all_items.sort(key=lambda n: int(n.kwval.get('sold', 0)), reverse=True)

    line(1)
    print(f"|{'Top 5 Best-Selling Items':^138}|")
    line(1)
    for node in all_items[:5]:

        price = float(node.kwval.get('price', 0))
        sold = int(node.kwval.get('sold', 0))
        profit = price * sold
        attributes = {"profit": f"{profit:.2f}", "stock": node.kwval.get('stock', 0), "sold": node.kwval.get('sold', 0)}
        print(f"| {node.key:^67} |", end="")
        for k, v in attributes.items():
            print(f"  {f"{k}: {v}":18}  |", end="")
        print()
    line(1)

    print(f"|{'Top 5 Worst-Selling Items':^138}|")
    line(1)
    for node in all_items[-5:]:
        price = float(node.kwval.get('price', 0))
        sold = int(node.kwval.get('sold', 0))
        profit = price * sold
        attributes = {"profit": f"{profit:.2f}", "stock": node.kwval.get('stock', 0), "sold": node.kwval.get('sold', 0)}
        print(f"| {node.key:^67} |", end="")
        for k, v in attributes.items():
            print(f"  {f"{k}: {v}":18}  |", end="")
        print()
    line(1)


# Display items with stock less than 5 with price
def restock_report():
    low_stock_items = []
    for linked_list in inventory:
        for node in linked_list:
            stock = int(node.kwval.get('stock', 0))
            sold = int(node.kwval.get('sold', 0))
            if stock < 5 and sold > 0:
                low_stock_items.append(node)

    line(1)
    print(f"|{'Restock Alert: ':^138}|")
    line(1)
    if not low_stock_items:
        print(f"|{'None of the items need to restock':^138}|")
    else:
        for node in low_stock_items:
            attributes = {"price": node.kwval.get('price', 0), "stock": node.kwval.get('stock', 0), "sold": node.kwval.get('sold', 0)}
            print(f"| {node.key:^67} |", end="")
            for k, v in attributes.items():
                print(f"  {f"{k}: {v}":18}  |", end="")
            print()
    line(1)


def report_menu():
    while True:
        print('-' * 89)
        print(f"|{'Function List:':86}|")
        print(f"|{'0. Quit':86}|")
        print(f"|{'1. Inventory Report':86}|")
        print(f"|{'2. Sales Report':86}|")
        print(f"|{'3. Restock Report':86}|")
        print(f"|{'* Function 3 will display items with stock < 5 and sold > 0 with profit':86}|")
        print('-' * 89)
        choice = input("Enter the number of function (0-3): ")

        match choice:
            case '0':
                break
            case '1':
                get_inventory()
                input("Press enter to continue")
                clear_screen()
            case '2':
                get_top5_report()
                input("Press enter to continue")
                clear_screen()
            case '3':
                restock_report()
                input("Press enter to continue")
                clear_screen()
            case _:
                print("Invalid input. Please choose a number between 0 and 3.")


if __name__ == "__main__":
    report_menu()
