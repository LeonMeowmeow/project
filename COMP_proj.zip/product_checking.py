from readio import clear_screen, inventory

all_item = []


def update():
    global all_item
    all_item = []
    for linked_list in inventory.table:
        for node in linked_list:
            all_item.append(node)


reverse = False


def line():
    print("-"*145)


def pr_menu():
    print('-'*89)
    print(f'|{'Function List:':86} |')
    print(f'|{'0. Quit':86} |')
    print(f'|{'1. A-Z':86} |')
    print(f'|{'2. Inventory Volume':86} |')
    print(f'|{'3. Price':86} |')
    print(f'|{'4. Sold':86} |')
    print(f'|{'5. Category':86} |')
    print(f'|{'6. Search Product':86} |')
    print('|tip: Before choosing the function, Input A/D to chose order by ascending or descending |')
    print('-'*89)


def Product_C():
    while True:
        pr_menu()
        ChooseC = input('Enter the number of function(0-6): ')
        match ChooseC:
            case '0':
                break
            case '1':
                A_Z()
                input("Press enter to continue")
                clear_screen()
            case '2':
                Stock_V()
                input("Press enter to continue")
                clear_screen()
            case '3':
                price()
                input("Press enter to continue")
                clear_screen()
            case '4':
                sold()
                input("Press enter to continue")
                clear_screen()
            case '5':
                category()
                input("Press enter to continue")
                clear_screen()
            case '6':
                search()
                input("Press enter to continue")
                clear_screen()
            case _:
                global reverse
                if ChooseC.lower() == 'd':
                    reverse = True
                elif ChooseC.lower() == 'a':
                    reverse = False
                else:
                    print('Invalid input')


def A_Z():
    update()
    all_item.sort(key=lambda n: n.key, reverse=reverse)
    line()
    for node in all_item:
        print(f"|{node.key:^69}|", end="")
        for k, v in node.kwval.items():
            if k == "category":
                print(f"  {f"{k}: {v}":21}  |", end="")
            else:
                print(f"  {f"{k}: {v}":11}  |", end="")
        print()
    line()


def Stock_V():
    update()
    all_item.sort(key=lambda n: int(n.kwval.get('stock', 0)), reverse=reverse)
    line()
    for node in all_item:
        print(f"|{node.key:^69}|", end="")
        for k, v in node.kwval.items():
            if k == "category":
                print(f"  {f"{k}: {v}":21}  |", end="")
            else:
                print(f"  {f"{k}: {v}":11}  |", end="")
        print()
    line()


def price():
    update()
    all_item.sort(key=lambda n: int(n.kwval.get('price', 0)), reverse=reverse)
    line()
    for node in all_item:
        print(f"|{node.key:^69}|", end="")
        for k, v in node.kwval.items():
            if k == "category":
                print(f"  {f"{k}: {v}":21}  |", end="")
            else:
                print(f"  {f"{k}: {v}":11}  |", end="")
        print()
    line()


def sold():
    update()
    all_item.sort(key=lambda n: int(n.kwval.get('sold', 0)), reverse=reverse)
    line()
    for node in all_item:
        print(f"|{node.key:^69}|", end="")
        for k, v in node.kwval.items():
            if k == "category":
                print(f"  {f"{k}: {v}":21}  |", end="")
            else:
                print(f"  {f"{k}: {v}":11}  |", end="")
        print()
    line()


def category():
    update()
    all_item.sort(key=lambda n: n.kwval.get('category', 0), reverse=reverse)
    line()
    for node in all_item:
        print(f"|{node.key:^69}|", end="")
        for k, v in node.kwval.items():
            if k == "category":
                print(f"  {f"{k}: {v}":21}  |", end="")
            else:
                print(f"  {f"{k}: {v}":11}  |", end="")
        print()
    line()


def search():
    line()
    find = False
    key = input("Please type the product you want to find: ")
    node = inventory.get_list(key).get_node(key)
    if node:
        if (node.key == key):
            find = True
        else:
            print(f"Sorry, the product '{key}' was not found.")
            find = False
        if find is True:
            print(f"The data in {key} is:")
            for k, v in node.kwval.items():
                print(f" {k}: {v}")
    else:
        print(f"Sorry, the product '{key}' was not found.")
    line()


if __name__ == "__main__":
    Product_C()
