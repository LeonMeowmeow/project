import os
from hashtable import HashTable
FILENAME: str = os.path.join(os.path.dirname(__file__), "inventoryfile.txt")

inventory = HashTable(100)


def reader(filename):
    with open(filename) as file:
        yield from file


def line(num=0):
    print("-"*(139+num))


# clear screen
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")
