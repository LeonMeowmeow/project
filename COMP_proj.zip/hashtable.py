from typing import Optional, Any
from dataclasses import dataclass, field


@dataclass  # DataClass 'Node' for storing data of each node
class Node:
    key: str
    # kwval means keyword value , used for storing all the keyword values
    kwval: dict[str, Any] = field(default_factory=dict)
    next: Optional["Node"] = field(repr=False, init=False, default=None)

    # set the format printed, usually use for writing nodes to the file
    def __str__(self):
        return f"{self.key}," + ",".join(f"{k}:{self.kwval[k]}" for k in self.kwval)


class LinkedList:
    def __init__(self):
        self.first: Optional[Node] = None  # type: ignore

    def add(self, key: str, **kwval: Any) -> None:
        """Add the node at the beginning."""
        new_node = Node(key, kwval)
        new_node.next = self.first
        self.first = new_node

    def remove(self, key: str) -> bool:
        """Remove the node"""
        current: Optional[Node] = self.first
        previous: Optional[Node] = None
        while (current):
            if (current.key == key):
                if (previous):
                    previous.next = current.next
                else:
                    self.first = current.next
                return True
            previous, current = current, current.next
        return False

    def change(self, key: str, *val: str, **kwval: Any) -> bool:
        """Change the attributes of the node."""
        # if not exist -> return False
        node: Optional[Node] = self.get_node(key)
        if (node is None):
            return False
        # start change (remove / change / add)
        for k in val:
            node.kwval.pop(k, None)
        node.kwval.update(kwval)
        return True

    # get a single node
    def get_node(self, key: str) -> Optional[Node]:
        """Get and return node. If can't find, return None"""
        for node in self:
            if (node.key == key):
                return node
        return None

    # define print format
    def __str__(self):
        return str([[node.key, node.kwval] for node in self])

    # change the LinkedList to the iterator
    def __iter__(self):
        current = self.first
        while (current is not None):
            yield current
            current = current.next


class HashTable:
    def __init__(self, size: int):
        """
        Create a hashTable by the size input.

        :param int size: The size of the hash table.
        """
        self.size = size
        self.table = [LinkedList() for _ in range(self.size)]

    def add(self, key: str, **kwval: Any) -> None:
        """
        Add the node into hash table.

        :param str key: The key of the node.
        :param kwval: The attributes want to add into the node.
        :raises KeyError: If the key already exist.

        Examples
        --------
        >>> hasht.add("key1", quantity = 1, color = "red")
        >>> hasht.add("key1")
        Traceback (most recent call last):
            ...
        KeyError: "The key 'key1' already exists."
        """
        element = self.get_list(key)
        if (element.get_node(key)):
            raise KeyError(f"The key '{key}' already exist.")
        element.add(key, **kwval)

    def get_list(self, key: str) -> LinkedList:
        """
        Search in table for the key. Return LinkedList object.

        :param str key: The key of the node.
        :returns: LinkedList Object.

        Examples
        --------
        >>> hasht.add("key1", quantity = 1)     # add a node
        >>> hasht.get_list("key1")              # search the node
        [['key1', {'quantity': 1}]]             # returns the LinkedList object

        >>> hasht.get_list("key2")              # search for non-exist node
        []                                      # returns empty list
        """
        # calculate the index for the key input
        index = hash(key) % self.size
        return self.table[index]

    def remove(self, key: str, default=set()) -> None:
        """
        Remove the node of the key.
        If the node is not found, return default value; otherwise, raise a KeyError.

        :param str key: The key of the node.
        :raises KeyError: If the key is not exist.
        :return: The `default` value.

        Examples
        --------
        >>> hasht.add("key1")                   # add a node
        >>> hasht.remove("key1")                # remove the node
        # Returns None

        >>> hasht.add("key1")                   # add a node
        >>> hasht.remove("key0")                # remove the non-exist node
        Traceback (most recent call last):      # raise a KeyError
            ...
        KeyError: "The key 'key0' is not exist"

        >>> hasht.add("key1")                   # add a node
        >>> hash.remove("key0", None)           # remove the non-exist node with default value
        None                                    # return the `default` value (None)
        """
        # get the linked list element
        element = self.get_list(key)
        # remove the node of the key and get the return value
        retval = element.remove(key)
        # if return value is False -> the node can't be found
        if (retval is False):
            if (default == set()):
                raise KeyError(f"The key '{key}' is not exist.")
            else:
                return default

    def change(self, key: str, *val: str, **kwval: Any) -> None:
        """
        Changes or adds or removes the elements.

        :param str key: The key of the node.
        :param str val: The attributes want to remove.
        :param kwval: The attributes want to change.
        :raises KeyError: If the key is not exist.

        Examples
        --------
        >>> hasht.add("key1")                       # add a node without attribute
        >>> hasht.change("key1","quantity")         # remove the attribute of the node
        # returns None

        >>> hasht.add("key1")                       # add a node without attribute
        >>> hasht.change("key1", quantity = 2)      # change the attribute of the node
        # returns None

        >>> hasht.add("key1")                       # add a node without attribute
        >>> hasht.change("key0")                    # change a non-exist node
        Traceback (most recent call last):          # raises KeyError
            ...
        KeyError: "The key 'key0' is not exist."
        """
        # get the linked list element
        element = self.get_list(key)
        # if return value is False -> the node can't be found
        retval = element.change(key, *val, **kwval)
        if (retval is False):
            raise KeyError(f"The key '{key}' is not exist.")

    def get_attr(self, key: str, *attr: str) -> None:
        """
        Get and print the element of the key.

        :param str key: The key of the node.
        :param str attr: The attributes want to be printed.
        :raises KeyError: If the key is not exist.

        Examples
        --------
        >>> hasht.add("key1", quantity = 1, color = "red")      # add the node with attributes
        >>> hasht.get_attr("key1", "quantity")                  # get the attribute of `quantity`
        The attributes 'quantity' in key 'key1':                # print the output
            quantity : 1

        >>> hasht.add("key1", quantity = 1, color = "red")      # add the node with attributes
        >>> hasht.get_attr("key1")                              # get all attributes
        The attributes in key 'key1':                           # print attributes
            quantity : 1
            color : red

        >>> hasht.add("key1", quantity = 1, color = "red")      # add the node with attributes
        >>> hasht.get_attr("key0")                              # get the non-exist node
        Traceback (most recent call last):                      # raises KeyError
            ...
        KeyError: "The key 'key0' is not exist."

        """
        # get the LinkedList of the index of the key input
        element = self.get_list(key)
        # get the attributes in the LinkedList node (ret means return value)
        ret = element.get_node(key)
        # if the node not exist -> raise KeyError
        if (ret is None):
            raise KeyError(f"The key '{key}' is not exist.")
        # if no specific attribute -> print all attributes
        kwval = ret.kwval
        if not (attr):
            print(f"The attributes in key '{key}':")
            for i in kwval:
                print(f" {i} : {kwval[i]}")

        # if specify the attributes -> only print them out
        else:
            print(f"The attributes '{", ".join(attr)}' in key '{key}' :", end="")
            # flag for whether the attribute exist
            attr_in_dict = False
            for i in kwval:
                if (i in attr):
                    print(f"\n {i} : {kwval[i]}", end="")
                    # if the attribute exist -> change the flag to True
                    attr_in_dict = True
            # if the attribute is not exist -> print not exist
            if (attr_in_dict is False):
                print(f"\rThe attributes '{", ".join(attr)}' in key '{key}' is not exist", end="")
            print()

    # define the print format
    def __str__(self):
        return ",\n".join(str(linkedlist) for linkedlist in self.table)

    # change the HashTable to an iterator
    def __iter__(self):
        index = 0
        while (index < self.size):
            yield self.table[index]
            index += 1
