# time compare
from hashtable import HashTable, LinkedList
from readio import reader
import os
from random import randint
from time import time
FILENAME: str = os.path.join(os.path.dirname(__file__), "inventoryfile.txt")

Product = HashTable(100)
List = LinkedList()
List1 = []

for line in reader(FILENAME):
    line = line.strip("\n")
    line_split = line.split(",")
    key = line_split[0]
    key_val_dict = {}
    for i in range(1, len(line_split)):
        key_val_dict[line_split[i].split(":")[0]] = line_split[i].split(":")[1]
    Product.add(key, **key_val_dict)

for line in reader(FILENAME):
    line = line.strip("\n")
    line_split = line.split(",")
    key = line_split[0]
    key_val_dict = {}
    for i in range(1, len(line_split)):
        key_val_dict[line_split[i].split(":")[0]] = line_split[i].split(":")[1]
    List.add(key, **key_val_dict)

for linked_list in Product.table:
    for node in linked_list:
        List1.append(node)


def getkey():
    index = randint(0, 99)
    key = List1[index].key
    return key


def compare_time():
    k = getkey()
    start1 = time()
    Product.get_list(k).get_node(k)
    end1 = time()
    time1 = end1 - start1
    start2 = time()
    List.get_node(k)
    end2 = time()
    time2 = end2 - start2
    return time1, time2


def looping(num):
    time1_t = 0
    time2_t = 0
    for i in range(num):
        time1, time2 = compare_time()
        time1_t += time1
        time2_t += time2
    return time1_t, time2_t


def faster(num):
    hash = 0
    LL = 0
    for i in range(num):
        hash_total_time, linked_total_time = looping(100000)
        if hash_total_time < linked_total_time:
            hash += 1
        else:
            LL += 1
    return hash, LL, hash_total_time, linked_total_time


def Line():
    print('-'*60)


for i in range(10):
    hash_f, linked_f, hash_total_time, linked_total_time = faster(10)
    Line()
    print(f'|{i+1:<57} |')
    print('|The number of time for searching key faster than other:   |')
    print(f'|        Hash_Table:{hash_f:<9n}|        Linked_List:{linked_f:<9n}|')
    print(f'|   Total Time:{hash_total_time:<14n}|    Total Time:{linked_total_time:<14n}|')
    Line()
    if i == 9:
        print('Finish running OwOb')
        Line()
